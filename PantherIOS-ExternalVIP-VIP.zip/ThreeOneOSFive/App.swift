import SwiftUI
import UIKit
import AVFoundation
import Security

@MainActor
enum PantherFeedbackAudio {
    static var player: AVAudioPlayer?
    static func play(_ name: String) {
        guard let url = Bundle.main.url(forResource: name, withExtension: "m4a") else {
            print("Audio no encontrado en el bundle: \(name).m4a")
            return
        }
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [.mixWithOthers])
            try AVAudioSession.sharedInstance().setActive(true)
            player = try AVAudioPlayer(contentsOf: url)
            player?.prepareToPlay()
            player?.play()
        } catch {
            print("No se pudo reproducir el audio: \(error.localizedDescription)")
        }
    }
}


@main
struct ThreeOneOSFiveApp: App {
    @StateObject private var appState = AppState()
    @StateObject private var pantherSession = PantherSession()
    @StateObject private var patchDraftCoordinator = PatchDraftCoordinator()
    @StateObject private var fileOperationCoordinator = FileOperationCoordinator()
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @State private var showOnboarding = false
    @State private var demoUnlocked = false
    @State private var showAttribution = false
    @State private var updateOffer: AppUpdateChecker.Offer?
    @Environment(\.scenePhase) private var scenePhase

    init() {
        setupLogCapture()
        log("app: 3105 launching — iOS \(AppInfo.osVersion) (\(AppInfo.osBuild)) \(AppInfo.machineName)")
    }

    private var language: AppLanguage {
        AppLanguage(rawValue: languageCode) ?? .english
    }

    private func checkForUpdate() {
        Task {
            guard let offer = await AppUpdateChecker.check() else { return }
            await MainActor.run { updateOffer = offer }
        }
    }

    var body: some Scene {
        WindowGroup {
            ZStack {
                Group {
                    #if DEBUG_PATCHES
                    // Development-only UI preview. No key, role or server permissions are granted.
                    PatchProjectsView(ghostTheme: true)
                        .background(Color.black.ignoresSafeArea())
                        .statusBarHidden(true)
                    #else
                    if !demoUnlocked {
                        ExternalVIPKeyView { demoUnlocked = true }
                    } else {
                        ExternalVIPDashboardView(onLogout: { demoUnlocked = false })
                    }
                    /* Original server-authenticated routes are retained in source for reference.
                    if pantherSession.role == nil {
                        PantherLoginView(session: pantherSession)
                    } else if pantherSession.role == "patches" {
                        PantherAssignedPatchesView(session: pantherSession)
                    } else {
                        ContentView()
                    }
                    */
                    #endif
                }
                    .environmentObject(appState)
                    .environmentObject(pantherSession)
                    .environmentObject(patchDraftCoordinator)
                    .environmentObject(fileOperationCoordinator)
                    .environment(\.appLanguage, language)
                    .environment(\.locale, language.locale)
                    .opacity(showOnboarding && pantherSession.role != nil ? 0 : 1)
                    .allowsHitTesting(!showOnboarding || pantherSession.role == nil)

                if false && showOnboarding && pantherSession.role != nil {
                    OnboardingView {
                        OnboardingStore.markCompleted()
                        withAnimation(.spring(response: 0.42, dampingFraction: 0.86)) {
                            showOnboarding = false
                        }
                        appState.detectSupport()
                        // Automatic update prompt disabled.
                    }
                    .environment(\.appLanguage, language)
                    .environment(\.locale, language.locale)
                    .transition(.opacity.combined(with: .scale(scale: 0.98)))
                    .zIndex(1)
                }
            }
            .displayIdentityAttribution(isPresented: $showAttribution, enabled: !showOnboarding && pantherSession.role == "admin")
            .sheet(isPresented: $showAttribution) {
                DisplayAttributionSheet()
            }
            .alert(item: $updateOffer) { offer in
                Alert(
                    title: Text(language.text("update.title")),
                    message: Text(language.text("update.message", offer.version)),
                    primaryButton: .default(Text(language.text("update.agree"))) {
                        // No external GitHub navigation from the patch menu.
                    },
                    secondaryButton: .cancel(Text(language.text("update.dismiss"))) {
                        AppUpdateChecker.dismiss(version: offer.version)
                    }
                )
            }
            .task {
                await pantherSession.restoreSavedKey()
            }
            .onAppear {
                if !showOnboarding && pantherSession.role != nil {
                    appState.detectSupport()
                    // Automatic update prompt disabled.
                }
            }
            .onChange(of: scenePhase) { phase in
                guard phase == .active, !showOnboarding, pantherSession.role != nil else { return }
                appState.detectSupport()
            }
            .task(id: pantherSession.role) {
                // Re-check the active key with Lovable every 30 seconds while logged in.
                // SwiftUI cancels this task automatically when the role changes.
                guard pantherSession.role != nil else { return }
                PantherBundledPackages.installIfNeeded()
                await pantherSession.revalidate()
                while !Task.isCancelled && pantherSession.role != nil {
                    do {
                        try await Task.sleep(nanoseconds: 30_000_000_000)
                    } catch { break }
                    guard !Task.isCancelled, pantherSession.role != nil else { break }
                    await pantherSession.revalidate()
                }
            }
            .onChange(of: scenePhase) { phase in
                if phase == .active { Task { await pantherSession.revalidate() } }
            }
            .onOpenURL { url in
                if pantherSession.role == "admin" { patchDraftCoordinator.presentImport(url) }
            }
        }
    }
}


// Pantalla de acceso External VIP con clave local de demostración.
// Los ceros iniciales se conservan al introducirlos.
private 
struct ExternalVIPKeyView: View {
    let onUnlock: () -> Void
    @State private var key = ""
    @State private var error = ""

    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color(red: 0.025, green: 0.022, blue: 0.035).ignoresSafeArea()
                VStack(spacing: 0) {
                    Spacer().frame(height: geo.size.height * 0.085)
                    ZStack {
                        Circle().fill(Color(red: 0.075, green: 0.055, blue: 0.13))
                            .frame(width: 150, height: 150)
                        Image(systemName: "key.fill")
                            .font(.system(size: 62, weight: .bold))
                            .foregroundStyle(Color(red: 0.57, green: 0.25, blue: 1.0))
                            .rotationEffect(.degrees(-35))
                    }
                    Spacer().frame(height: 54)
                    Text("Activar Key")
                        .font(.system(size: 36, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                    Text("Activa tu key para acceder al sistema")
                        .font(.system(size: 18))
                        .foregroundStyle(Color.white.opacity(0.62))
                        .padding(.top, 22)
                    VStack(alignment: .leading, spacing: 16) {
                        Text("CLAVE DE ACCESO")
                            .font(.system(size: 15, weight: .bold))
                            .foregroundStyle(Color.white.opacity(0.78))
                        TextField("EJ:  Lxz-XXXXXX", text: $key)
                            .textInputAutocapitalization(.characters)
                            .autocorrectionDisabled()
                            .font(.system(size: 21))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 20)
                            .frame(height: 64)
                            .background(Color(red: 0.075, green: 0.065, blue: 0.095))
                            .clipShape(RoundedRectangle(cornerRadius: 23))
                            .overlay(RoundedRectangle(cornerRadius: 23).stroke(Color(red: 0.25, green: 0.16, blue: 0.43), lineWidth: 1.4))
                        if !error.isEmpty {
                            Text(error).font(.caption.weight(.semibold)).foregroundStyle(.red)
                        }
                        Button {
                            if key.trimmingCharacters(in: .whitespacesAndNewlines).uppercased() == "VIP" {
                                onUnlock()
                            } else {
                                error = "Key incorrecta. Inténtalo de nuevo."
                            }
                        } label: {
                            Text("ACCEDER AL SISTEMA")
                                .font(.system(size: 18, weight: .bold))
                                .foregroundStyle(key.isEmpty ? Color.white.opacity(0.32) : .white)
                                .frame(maxWidth: .infinity)
                                .frame(height: 66)
                                .background(Color(red: 0.055, green: 0.05, blue: 0.075))
                                .clipShape(RoundedRectangle(cornerRadius: 22))
                        }
                        .disabled(key.isEmpty)
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 62)
                    Spacer()
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .preferredColorScheme(.dark)
    }
}

struct ExternalVIPDashboardView: View {
    let onLogout: () -> Void
    @State private var enabled: Set<String> = []
    @State private var selectedMode = "AIMBOT"

    private let items = ["PECHO AVATAR", "HEAD AVATAR", "CUELLO AVATAR", "SINTURA AVATAR"]

    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black.ignoresSafeArea()
                Image("GhostPatchesBackground")
                    .resizable()
                    .scaledToFill()
                    .frame(width: geo.size.width, height: geo.size.height)
                    .clipped()
                    .overlay(Color.black.opacity(0.38))
                VStack(spacing: 0) {
                    HStack {
                        Button(action: onLogout) {
                            Image(systemName: "chevron.left")
                                .font(.system(size: 22, weight: .bold))
                                .foregroundStyle(.white)
                                .frame(width: 46, height: 46)
                                .background(.ultraThinMaterial, in: Circle())
                        }
                        Spacer()
                        Link(destination: URL(string: "https://t.me/Lxz_iOS")!) {
                            Image(systemName: "gearshape.fill")
                                .font(.system(size: 22, weight: .bold))
                                .foregroundStyle(.white)
                                .frame(width: 46, height: 46)
                                .background(.ultraThinMaterial, in: Circle())
                        }
                    }
                    .padding(.horizontal, 22)
                    .padding(.top, 12)

                    Image("FFMaxNarutoCollab")
                        .resizable().scaledToFill()
                        .frame(width: 76, height: 76)
                        .clipShape(RoundedRectangle(cornerRadius: 18))
                        .overlay(RoundedRectangle(cornerRadius: 18).stroke(.white.opacity(0.35), lineWidth: 1))
                        .padding(.top, 16)
                    Text("E X T E R N A L   V I P")
                        .font(.system(size: 17, weight: .heavy))
                        .foregroundStyle(.white)
                        .padding(.top, 13)
                    Text("Panel De Control")
                        .font(.system(size: 32, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                        .padding(.top, 44)
                    Text("● FREE FIRE TH")
                        .font(.system(size: 20, weight: .bold))
                        .foregroundStyle(.cyan)
                        .padding(.top, 18)

                    HStack {
                        Circle().fill(.green).frame(width: 10, height: 10)
                        Text("System Ready")
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundStyle(.white.opacity(0.85))
                        Spacer()
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 48)

                    HStack(spacing: 12) {
                        modeButton("AIMBOT")
                        modeButton("HOLO ARM")
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 22)

                    VStack(spacing: 10) {
                        ForEach(items, id: \.self) { item in
                            Button {
                                if enabled.contains(item) { enabled.remove(item) }
                                else { enabled.insert(item) }
                            } label: {
                                HStack(spacing: 15) {
                                    Image(systemName: "scope")
                                        .font(.system(size: 27, weight: .medium))
                                        .foregroundStyle(.cyan)
                                        .frame(width: 46)
                                    VStack(alignment: .leading, spacing: 5) {
                                        Text(item)
                                            .font(.system(size: 17, weight: .bold))
                                            .foregroundStyle(.white)
                                        Text("Paquete .3105 · Vista de demostración")
                                            .font(.system(size: 12, weight: .medium))
                                            .foregroundStyle(.white.opacity(0.68))
                                            .lineLimit(1)
                                    }
                                    Spacer(minLength: 0)
                                    ZStack(alignment: enabled.contains(item) ? .trailing : .leading) {
                                        Capsule().fill(enabled.contains(item) ? Color.cyan : Color.gray.opacity(0.45))
                                            .frame(width: 58, height: 34)
                                        Circle().fill(.white).frame(width: 27, height: 27).padding(.horizontal, 4)
                                    }
                                }
                                .padding(.horizontal, 16)
                                .frame(height: 76)
                                .background(Color.black.opacity(0.72), in: RoundedRectangle(cornerRadius: 21))
                                .overlay(RoundedRectangle(cornerRadius: 21).stroke(Color.cyan.opacity(0.9), lineWidth: 1.2))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 22)

                    Spacer(minLength: 12)
                    HStack(spacing: 12) {
                        Image(systemName: "person.circle.fill")
                            .font(.system(size: 34))
                            .foregroundStyle(.cyan)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("VIP-1Day-TEST")
                                .font(.system(size: 16, weight: .bold))
                                .foregroundStyle(.white)
                            Text("Acceso de prueba")
                                .font(.system(size: 12))
                                .foregroundStyle(.white.opacity(0.7))
                        }
                        Spacer()
                        Text("1 Day")
                            .font(.system(size: 17, weight: .heavy))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 19)
                            .padding(.vertical, 12)
                            .background(Color.cyan, in: Capsule())
                    }
                    .padding(.horizontal, 18)
                    .frame(height: 84)
                    .background(Color.black.opacity(0.78), in: RoundedRectangle(cornerRadius: 20))
                    .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.cyan, lineWidth: 1.5))
                    .padding(.horizontal, 20)
                    .padding(.bottom, 22)
                }
            }
            .frame(width: geo.size.width, height: geo.size.height)
        }
        .preferredColorScheme(.dark)
    }

    private func modeButton(_ title: String) -> some View {
        Button { selectedMode = title } label: {
            Text(title)
                .font(.system(size: 14, weight: .bold))
                .foregroundStyle(selectedMode == title ? .white : .cyan)
                .frame(maxWidth: .infinity)
                .frame(height: 48)
                .background(selectedMode == title ? Color.cyan.opacity(0.9) : Color.black.opacity(0.35), in: Capsule())
                .overlay(Capsule().stroke(Color.cyan, lineWidth: 1))
        }
        .buttonStyle(.plain)
    }
}

class AppState: ObservableObject {
    @Published var exploitStatus: ExploitStatus = .notStarted
    @Published var unsupportedMessage: String?
    @Published var kernelExploitRunning = false

    private var autoRunAttempted = false

    var kernelExploitApplicable: Bool {
        KernelExploit.isApplicable(
            major: AppInfo.versionTuple.major,
            minor: AppInfo.versionTuple.minor,
            patch: AppInfo.versionTuple.patch,
            build: AppInfo.osBuild
        )
    }

    var isSupported: Bool { unsupportedMessage == nil }

    func detectSupport() {
        let v = AppInfo.versionTuple
        let supported = ExploitSupportPolicy.isSupported(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
#if targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--simulate-access") {
            exploitStatus = .success(method: "Simulator preview")
        }
#endif

        unsupportedMessage = supported ? nil : "iOS \(AppInfo.osVersion) (\(AppInfo.osBuild))"
        if let unsupportedMessage {
            exploitStatus = .unsupported(unsupportedMessage)
            return
        }

        let applicable = KernelExploit.isApplicable(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
        guard applicable else { return }

        refreshKernelExploitStatus()
        maybeAutoRunKernelExploit()
    }

    private func maybeAutoRunKernelExploit() {
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed,
              !autoRunAttempted else { return }
        autoRunAttempted = true
        log("app: starting kernel exploit automatically")
        runKernelExploitIfNeeded()
    }

    private func refreshKernelExploitStatus() {
        guard !kernelExploitRunning else { return }

        // iOS < 26: kernel R/W success persists (no sandbox probe)
        // iOS >= 26: verify full sandbox escape is still active
        if KernelExploit.requiresSandboxEscape {
            if KernelExploit.hasSandboxAccess() {
                if !exploitStatus.isSuccess {
                    exploitStatus = .success(method: "kexploit")
                    log("app: existing sandbox access is still active; skipping kernel exploit")
                }
            } else if exploitStatus.isSuccess {
                exploitStatus = .notStarted
                log("app: sandbox access is no longer active")
            }
        }
    }

    func runKernelExploitIfNeeded() {
        refreshKernelExploitStatus()
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed else { return }
        kernelExploitRunning = true
        exploitStatus = .notStarted
        log("app: running kernel exploit on background...")
        DispatchQueue.global(qos: .userInitiated).async {
            let ok = KernelExploit.run()
            DispatchQueue.main.async {
                self.kernelExploitRunning = false
                if ok {
                    self.exploitStatus = .success(method: "kexploit")
                    if KernelExploit.requiresSandboxEscape {
                        log("app: kernel exploit success — sandbox access verified")
                    } else {
                        log("app: kernel exploit success — kernel access active")
                    }
                } else {
                    self.exploitStatus = .failed(method: "kexploit", code: -1)
                    log("app: kernel exploit failed — relaunch the app before retrying")
                }
            }
        }
    }
}


// MARK: - Panther iOS license API (Lovable)
@MainActor
final class PantherSession: ObservableObject {
    @Published var role: String?
    @Published var expiresAt: Date?
    @Published var permanent = false
    @Published var expiredNotice = false
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var publishedPatches: [PantherPatch] = []
    @Published var catalogMessage: String?
    @Published var catalogLoading = false

    private let apiBase = (Bundle.main.object(forInfoDictionaryKey: "PantherAPIBaseURL") as? String ?? "")
        .trimmingCharacters(in: CharacterSet(charactersIn: "/"))
    // The key is saved in the iOS Keychain, never in a public app resource.
    private let savedKeyService = "PantherIOS.ActiveLicense"
    private let savedKeyAccount = "current-device"
    private var activeKey: String?

    private func saveKey(_ key: String) {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                    kSecAttrService as String: savedKeyService,
                                    kSecAttrAccount as String: savedKeyAccount]
        SecItemDelete(query as CFDictionary)
        var item = query
        item[kSecValueData as String] = Data(key.utf8)
        item[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        let status = SecItemAdd(item as CFDictionary, nil)
        if status != errSecSuccess { print("Could not save license in Keychain: \(status)") }
    }

    private func readSavedKey() -> String? {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                    kSecAttrService as String: savedKeyService,
                                    kSecAttrAccount as String: savedKeyAccount,
                                    kSecReturnData as String: true,
                                    kSecMatchLimit as String: kSecMatchLimitOne]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private func clearSavedKey() {
        SecItemDelete([kSecClass as String: kSecClassGenericPassword,
                       kSecAttrService as String: savedKeyService,
                       kSecAttrAccount as String: savedKeyAccount] as CFDictionary)
    }

    func restoreSavedKey() async {
        guard role == nil, !isLoading, let saved = readSavedKey() else { return }
        await activate(key: saved)
        // If revoked or expired, require a new key on the next launch.
        if role == nil, let errorMessage,
           errorMessage.contains("revocada") || errorMessage.contains("vencid") || errorMessage.contains("no existe") || errorMessage.contains("otro dispositivo") {
            clearSavedKey()
        }
    }
    private var deviceID: String {
        UIDevice.current.identifierForVendor?.uuidString ?? "unavailable-device"
    }

    private func post(_ path: String, key: String) async throws -> (Data, Int) {
        guard let url = URL(string: apiBase + path), url.scheme == "https" else {
            throw PantherAPIError.message("La URL HTTPS de Lovable no está configurada.")
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 20
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: ["key": key, "device_id": deviceID])
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw PantherAPIError.message("Respuesta HTTP no válida.")
        }
        return (data, http.statusCode)
    }

    private func message(_ data: Data, status: Int) -> String {
        let body = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]
        let code = body["error"] as? String ?? ""
        switch code {
        case "invalid_key": return "La key no existe."
        case "device_mismatch": return "Esta key está vinculada a otro dispositivo."
        case "revoked": return "Esta key fue revocada."
        case "expired": return "La key ha vencido."
        case "not_activated": return "La key aún no está activada."
        case "invalid_request": return "La key o el identificador del dispositivo no es válido."
        default: return "El servidor rechazó la solicitud (HTTP \\(status))."
        }
    }

    func activate(key: String) async {
        let enteredKey = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !enteredKey.isEmpty else { errorMessage = "Introduce una key."; return }
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }
        do {
            let (data, status) = try await post("/api/activate", key: enteredKey)
            guard (200...299).contains(status) else {
                errorMessage = message(data, status: status)
                return
            }
            let result = try JSONDecoder().decode(PantherActivationResponse.self, from: data)
            guard result.ok else { errorMessage = "La API no autorizó el acceso."; return }
            let isAdmin = result.role == "admin" && result.menus.contains("all")
            let isUser = result.role == "user" && result.menus.contains("patches")
            guard isAdmin || isUser else { errorMessage = "Permisos de acceso desconocidos."; return }
            guard result.permanent == true || result.expiry != nil else { errorMessage = "El servidor no devolvió la fecha de vencimiento."; return }
            if let date = result.expiry, date <= Date(), result.permanent != true { errorMessage = "Key vencida."; return }
            expiresAt = result.expiry
            permanent = result.permanent == true
            expiredNotice = false
            activeKey = enteredKey
            saveKey(enteredKey)
            role = isAdmin ? "admin" : "patches"
            await refreshCatalog()
        } catch {
            errorMessage = "No se pudo verificar la key: \\(error.localizedDescription)"
        }
    }

    func checkExpiry() {
        if role != nil && !permanent, let expiresAt, Date() >= expiresAt { signOut(expired: true) }
    }
    func revalidate() async {
        guard let activeKey, role != nil else { return }
        do {
            let (data, status) = try await post("/api/activate", key: activeKey)
            guard (200...299).contains(status) else {
                let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
                signOut(expired: (obj?["error"] as? String) == "expired")
                return
            }
            let result = try JSONDecoder().decode(PantherActivationResponse.self, from: data)
            guard result.ok, result.permanent == true || result.expiry != nil else { signOut(); return }
            expiresAt = result.expiry
            permanent = result.permanent == true
            checkExpiry()
        } catch { checkExpiry() }
    }
    func refreshCatalog() async {
        guard let activeKey else { return }
        catalogLoading = true
        catalogMessage = nil
        defer { catalogLoading = false }
        do {
            let (data, status) = try await post("/api/patches", key: activeKey)
            guard (200...299).contains(status) else {
                catalogMessage = message(data, status: status)
                return
            }
            let result = try JSONDecoder().decode(PantherPatchResponse.self, from: data)
            guard result.ok else { catalogMessage = "El catálogo no está disponible."; return }
            publishedPatches = result.patches
            if result.patches.isEmpty { catalogMessage = "No hay patches publicados todavía." }
        } catch {
            catalogMessage = "No se pudo actualizar el catálogo: \(error.localizedDescription)"
        }
    }

    // Descarga autenticada: el servidor debe validar key + dispositivo en cada solicitud.
    func downloadPatch(_ patch: PantherPatch) async throws -> URL {
        guard let activeKey else { throw PantherAPIError.message("Inicia sesión con una key válida.") }
        guard let identifier = patch.id.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) else {
            throw PantherAPIError.message("Identificador de patch inválido.")
        }
        let (data, status) = try await post("/api/patches/\(identifier)/download", key: activeKey)
        guard (200...299).contains(status) else { throw PantherAPIError.message(message(data, status: status)) }
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("PantherRemotePatches", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let filename = UUID().uuidString + ".3105"
        let destination = directory.appendingPathComponent(filename)
        try data.write(to: destination, options: [.atomic, .completeFileProtection])
        return destination
    }

    func signOut(expired: Bool = false) {
        clearSavedKey()
        expiredNotice = expired
        expiresAt = nil
        permanent = false
        publishedPatches = []
        catalogMessage = nil
        role = nil
        activeKey = nil
        errorMessage = nil
    }
}

private enum PantherAPIError: LocalizedError {
    case message(String)
    var errorDescription: String? {
        if case .message(let value) = self { return value }
        return nil
    }
}

private struct PantherActivationResponse: Decodable {
    let ok: Bool
    let role: String
    let menus: [String]
    let expires_at: String?
    let expires_at_ms: Double?
    let permanent: Bool?
    var expiry: Date? {
        if let expires_at_ms { return Date(timeIntervalSince1970: expires_at_ms / 1000) }
        guard let expires_at else { return nil }
        if let n = Double(expires_at) { return Date(timeIntervalSince1970: n > 10_000_000_000 ? n / 1000 : n) }
        let parser = ISO8601DateFormatter()
        if let date = parser.date(from: expires_at) { return date }
        parser.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return parser.date(from: expires_at)
    }
}

private struct PantherPatchResponse: Decodable {
    let ok: Bool
    let patches: [PantherPatch]
}

struct PantherPatch: Decodable, Identifiable {
    let id: String
    let name: String
    let description: String?
    let version: String?
    let category: String?
    let download_url: String?
}
private struct PantherNeonBrand: View {
    var body: some View {
        HStack(spacing: 6) {
            Image("PantherAppMark")
                .resizable()
                .scaledToFit()
                .frame(width: 59, height: 59)
                .clipShape(Circle())
            Text("Panther iOS")
                .font(.system(size: 37, weight: .bold, design: .serif))
                .italic()
                .foregroundStyle(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.75)
            Image(systemName: "crown.fill")
                .font(.system(size: 23))
                .foregroundStyle(.cyan)
        }
        .shadow(color: .cyan.opacity(0.9), radius: 8)
        .accessibilityElement(children: .combine)
    }
}

private struct PantherLoginView: View {
    @ObservedObject var session: PantherSession
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var key = ""

    var body: some View {
        GeometryReader { proxy in
            ZStack(alignment: .topLeading) {
                Color.black
                TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: reduceMotion)) { timeline in
                    let t = timeline.date.timeIntervalSinceReferenceDate
                    Image("GhostKeyBackground")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 390, height: 844)
                        .scaleEffect(reduceMotion ? 1.04 : 1.04 + 0.014 * sin(t * 1.8))
                        .offset(x: reduceMotion ? 0 : 6 * sin(t * 1.5),
                                y: reduceMotion ? 0 : 5 * sin(t * 2.0))
                        .frame(width: 390, height: 844)
                        .clipped()
                }
                PantherNeonBrand()
                    .frame(width: 350, height: 68)
                    .position(x: 195, y: 365)

                HStack(spacing: 12) {
                    Image(systemName: "key.fill")
                        .font(.system(size: 21))
                        .foregroundStyle(.white)
                    Rectangle()
                        .fill(Color.cyan.opacity(0.7))
                        .frame(width: 1, height: 27)
                    TextField("", text: $key,
                              prompt: Text("Ingresa tu Key")
                                .foregroundColor(.white.opacity(0.38)))
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .foregroundStyle(.white)
                        .font(.system(size: 20, weight: .medium))
                }
                .padding(.horizontal, 20)
                .frame(width: 350, height: 57)
                .background(Color.black.opacity(0.86), in: RoundedRectangle(cornerRadius: 19))
                .overlay(RoundedRectangle(cornerRadius: 19).stroke(Color.cyan, lineWidth: 2))
                .shadow(color: .cyan.opacity(0.75), radius: 8)
                .position(x: 195, y: 447)

                // The error is fixed between the input and button, so it never moves controls.
                Group {
                    if session.expiredNotice {
                        Text("Key vencida")
                    } else if let message = session.errorMessage {
                        Text(message)
                    }
                }
                .font(.system(size: 12, weight: .semibold))
                .foregroundStyle(.orange)
                .lineLimit(2)
                .multilineTextAlignment(.center)
                .frame(width: 340, height: 34)
                .position(x: 195, y: 492)

                Button {
                    Task { await session.activate(key: key) }
                } label: {
                    Label(session.isLoading ? "Verificando..." : "Entrar",
                          systemImage: "rectangle.portrait.and.arrow.right")
                        .font(.system(size: 22, weight: .bold))
                        .foregroundStyle(.white)
                        .frame(width: 275, height: 57)
                        .background(Color.black.opacity(0.85), in: RoundedRectangle(cornerRadius: 19))
                        .overlay(RoundedRectangle(cornerRadius: 19).stroke(Color.cyan, lineWidth: 2))
                        .shadow(color: .cyan.opacity(0.9), radius: 9)
                }
                .disabled(session.isLoading)
                .position(x: 195, y: 550)

                Text("¿No tienes una Key?")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(.white)
                    .position(x: 195, y: 685)

                Link(destination: URL(string: "https://t.me/+6L89Qcso3w9kN2Yx")!) {
                    Label("Únete a mi Telegram", systemImage: "paperplane.fill")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundStyle(.cyan)
                        .frame(width: 320, height: 52)
                        .background(Color.black.opacity(0.85), in: Capsule())
                        .overlay(Capsule().stroke(Color.cyan, lineWidth: 2))
                        .shadow(color: .cyan.opacity(0.6), radius: 7)
                }
                .position(x: 195, y: 735)
            }
            .frame(width: 390, height: 844)
            .scaleEffect(x: proxy.size.width / 390,
                         y: proxy.size.height / 844,
                         anchor: .topLeading)
            .frame(width: proxy.size.width, height: proxy.size.height, alignment: .topLeading)
        }
        .ignoresSafeArea()
        .statusBarHidden(true)
    }
}

// Normal keys use the same original patch project interface as the administrator.
// No per-key patch assignments, online catalog or separate package viewer.
private struct PantherAssignedPatchesView: View {
    @ObservedObject var session: PantherSession

    var body: some View {
        PatchProjectsView(ghostTheme: true)
            .background(Color.black.ignoresSafeArea())
            .statusBarHidden(true)
    }
}
