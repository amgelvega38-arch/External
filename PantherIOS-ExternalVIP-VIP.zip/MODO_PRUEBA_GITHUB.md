# External VIP — modo de demostración

- Al iniciar se muestra la pantalla Activar Key.
- Clave local de demostración: `VIP` (no es autenticación segura de producción).
- Tras entrar aparece el panel External VIP.
- Los interruptores del panel solo cambian su apariencia local; no ejecutan ni aplican parches.
- Los paquetes `.3105` originales no están incluidos en este ZIP.
