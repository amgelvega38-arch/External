# External VIP — cambios de interfaz

- Se eliminó la pantalla de calculadora y su desbloqueo por código numérico.
- La pantalla inicial ahora solicita una key con diseño oscuro y morado.
- Clave local de demostración: `VIP` (no sustituye autenticación remota segura).
- Después de ingresar se muestra el panel External VIP con diseño neón.
- Controles visibles: AIMBOT, HOLO ARM, PECHO AVATAR, HEAD AVATAR, CUELLO AVATAR y SINTURA AVATAR.
- Los controles del panel son únicamente visuales y no aplican modificaciones a Free Fire ni ejecutan paquetes.
- Los archivos binarios `.3105` originales no estaban incluidos en el ZIP de entrada; se conservaron únicamente los nombres documentados.
- El código Swift fue validado sintácticamente; no se compiló con Xcode ni se probó en un iPhone.
